
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author Student
 */

import java.util.Scanner;

public class Mhinga {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String name;
        String surname;
        String username;
        String password;
        String phoneNum;

        // Name
        System.out.println("Please enter your name:");
        name = input.nextLine();

        // Surname
        System.out.println("Please enter your surname:");
        surname = input.nextLine();

        // Username
        while (true) {
            System.out.println("Please enter your username:");
            username = input.nextLine();

            if (checkUserName(username)) {
                System.out.println("Username successfully entered.");
                break;
            } else {
                System.out.println("Username is not correctly formatted.");
                System.out.println("Username must contain an underscore.");
                System.out.println("Username must be not more than 5.");
            }
        }

        // Password
        while (true) {
            System.out.println("Please enter your password:");
            password = input.nextLine();

            if (checkPassword(password)) {
                System.out.println("Password successfully entered.");
                break;
            } else {
                System.out.println("Password is not correctly formatted.");
                System.out.println("Password must be at least 8 characters long.");
                System.out.println("Password must contain a capital letter.");
                System.out.println("Password must contain an underscore.");
                System.out.println("Password must contain a number.");
                System.out.println("Password must contain a special character.");
            }
        }

        // Phone number
        while (true) {
            System.out.println("Please enter your cellphone number:");
            phoneNum = input.nextLine();

            if (checkPhoneNum(phoneNum)) {
                System.out.println("Phone number successfully added.");
                break;
            } else {
                System.out.println("Cellphone number incorrectly formatted.");
                System.out.println("Cellphone number must start with +27.");
            }
        }

        // Register user
        String registrationMessage = registerUser(
                username,
                password,
                phoneNum,
                name,
                surname
        );

        System.out.println(registrationMessage);

        // Login
        boolean loginSuccessful = login.loginUser(
                input,
                username,
                password,
                name,
                surname
        );

        // Display login status
        String loginMessage = login.returnLoginStatus(
                loginSuccessful,
                name,
                surname
        );

        System.out.println(loginMessage);

        input.close();
    }

    // Check username
    public static boolean checkUserName(String username) {

        // Username must be at least 3 characters
        if (username.length() < 5) {
            return false;
        }

        // Username must contain an underscore
        if (!username.contains("_")) {
            return false;
        }

        // Count numbers
        int numberCount = 0;

        for (int i = 0; i < username.length(); i++) {
            char ch = username.charAt(i);

            if (Character.isDigit(ch)) {
                numberCount++;
            }
        }

        // Username must contain at least 2 numbers
        return numberCount >= 2;
    }

    // Check password
    public static boolean checkPassword(String password) {

        if (password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasUnderscore = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (int i = 0; i < password.length(); i++) {

            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                hasCapitalLetter = true;
            }

            if (ch == '_') {
                hasUnderscore = true;
            }

            if (Character.isDigit(ch)) {
                hasNumber = true;
            }

            // Special character means it is not a letter, number or underscore
            if (!Character.isLetterOrDigit(ch) && ch != '_') {
                hasSpecialCharacter = true;
            }
        }

        return hasCapitalLetter
                && hasUnderscore
                && hasNumber
                && hasSpecialCharacter;
    }

    // Check phone number
    public static boolean checkPhoneNum(String phoneNum) {

        return phoneNum.startsWith("+27");
    }

    // Register user
    public static String registerUser(
            String username,
            String password,
            String phoneNum,
            String name,
            String surname) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted.";
        }

        if (!checkPassword(password)) {
            return "Password is not correctly formatted.";
        }

        if (!checkPhoneNum(phoneNum)) {
            return "Phone number incorrectly formatted.";
        }

        return "Registration successfully completed.";
    }

}

 





       



    
   