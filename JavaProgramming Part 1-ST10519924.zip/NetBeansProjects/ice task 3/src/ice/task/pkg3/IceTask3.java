/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


import javax.swing.JOptionPane;

/**
 *
 * @author Student
 */

    
    public static void main(String[] args){
            
         String name = JOptionPane.showInputDialog(null, "Please enter your name");
        int age = Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter your age"));
        double height = Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter your height"));

    }        
         public static void call(String name, int age, double height){
        
        
          JOptionPane.showMessageDialog(null,"Name: " + name + "Age: " + age + "Height: " + height);
                 