/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkgswitch.structures;

/**
 *
 * @author Student
 */
import javax.swing.JOptionPane;
public class SwitchStructures {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String coulour = JOptionPane.showInputDialog(null,"Please choose a colour between Green, Orange and Red");
       
       switch (robots){
           
           case "Green": 
                JOptionPane.showMessageDialog(null, "It tells you to go.");
               break;
               
           case "Orange": 
                JOptionPane.showMessageDialog(null, "It tells you to start stopping.");
               break;
            
           case "Red": 
                JOptionPane.showMessageDialog(null, "It tells you to stop.");
               break;
               
            default:
                JOptionPane.showMessageDialog(null, "Enter another colour");
                break;
       }
    }
    
}
